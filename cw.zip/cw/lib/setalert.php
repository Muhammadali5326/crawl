<?php 

 	$user=$_POST['uservalue'];
 	$name=$_POST['namevalue'];
 	$off=$_POST['offvalue'];
	$web=$_POST['webvalue'];




?>