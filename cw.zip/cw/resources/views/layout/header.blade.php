<?php error_reporting(0); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
  <link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/elegant-font/html-css/style.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
  <style type="text/css">
    .modal.fade .modal-dialog {
    /* transition: -webkit-transform .3s ease-out; */
    /* transition: transform .3s ease-out; */
    /* transition: transform .3s ease-out,-webkit-transform .3s ease-out; */
    -webkit-transform: translate(0,-25%);
    transform: translate(0,-25%);
    top:26%;
}

  </style>
<!--===============================================================================================-->
</head>
<body class="animsition" id="body-fade">

  <!-- Header -->
  <header class="header1">
    <!-- Header desktop -->
    <div class="container-menu-header" style=" z-index: 99999;">
      <div class="topbar">
        <div class="topbar-social">
          <a href="#" class="topbar-social-item fa fa-facebook"></a>
          <a href="#" class="topbar-social-item fa fa-instagram"></a>
          <a href="#" class="topbar-social-item fa fa-pinterest-p"></a>
          <a href="#" class="topbar-social-item fa fa-snapchat-ghost"></a>
          <a href="#" class="topbar-social-item fa fa-youtube-play"></a>
        </div>

        <span class="topbar-child1">
          Register to get notified for your required product.
        </span>


      </div>

      <div class="wrap_header">
        <!-- Logo -->
        <a href="home" class="logo">
          <img src="images/icons/logo.png" alt="IMG-LOGO">
        </a>

        <!-- Menu -->
        <div class="wrap_menu">
          <nav class="menu">
            <ul class="main_menu">
              <li>
                <a href="home">Home</a>
                <!--<ul class="sub_menu">-->
                  <!--<li><a href="index.html">Homepage V1</a></li>-->
                  <!--<li><a href="home-02.html">Homepage V2</a></li>-->
                  <!--<li><a href="home-03.html">Homepage V3</a></li>-->
                <!--</ul>-->
              </li>

              <li>
                <a href="footwear">Footwear</a>
              </li>

              <li>
                <a href="brands">Brands</a>
              </li>

              <li>
                <a href="#">Signup</a>
              </li>

              <li>
                <a href="#">Signin</a>
              </li>

              <li>
                <input type="text" placeholder="search products" data-toggle="modal" data-target="#exampleModal" class="nodeinput" onclick="blur_body()">

              </li>
<!--
              <li>
                <a href="about.html">ABOUT</a>
              </li>

              <li>
                <a href="contact.html">CONTACT</a>
              </li>
            -->
            </ul>
          </nav>
        </div>
<!--
        <div class="header-search bo4">
        <a href="#" data-toggle="modal" data-target="#exampleModal">  <input class="s-text7 size6 p-l-23 p-r-50" type="text" name="search-product" placeholder="Search Products...">
</a>
         
          
        
        </div>


        <!-- Header Icon -->
        <div class="header-icons">
          <a href="#" class="header-wrapicon1 dis-block">
            <img src="images/icons/icon-header-01.png" class="header-icon1" alt="ICON">
          </a>

          <!--<span class="linedivide1"></span>-->

          <!--<div class="header-wrapicon2">-->
            <!--<img src="images/icons/icon-header-02.png" class="header-icon1 js-show-header-dropdown" alt="ICON">-->
            <!--<span class="header-icons-noti">0</span>-->

            <!--&lt;!&ndash; Header cart noti &ndash;&gt;-->
            <!--<div class="header-cart header-dropdown">-->
              <!--<ul class="header-cart-wrapitem">-->
                <!--<li class="header-cart-item">-->
                  <!--<div class="header-cart-item-img">-->
                    <!--<img src="images/item-cart-01.jpg" alt="IMG">-->
                  <!--</div>-->

                  <!--<div class="header-cart-item-txt">-->
                    <!--<a href="#" class="header-cart-item-name">-->
                      <!--White Shirt With Pleat Detail Back-->
                    <!--</a>-->

                    <!--<span class="header-cart-item-info">-->
                      <!--1 x $19.00-->
                    <!--</span>-->
                  <!--</div>-->
                <!--</li>-->

                <!--<li class="header-cart-item">-->
                  <!--<div class="header-cart-item-img">-->
                    <!--<img src="images/item-cart-02.jpg" alt="IMG">-->
                  <!--</div>-->

                  <!--<div class="header-cart-item-txt">-->
                    <!--<a href="#" class="header-cart-item-name">-->
                      <!--Converse All Star Hi Black Canvas-->
                    <!--</a>-->

                    <!--<span class="header-cart-item-info">-->
                      <!--1 x $39.00-->
                    <!--</span>-->
                  <!--</div>-->
                <!--</li>-->

                <!--<li class="header-cart-item">-->
                  <!--<div class="header-cart-item-img">-->
                    <!--<img src="images/item-cart-03.jpg" alt="IMG">-->
                  <!--</div>-->

                  <!--<div class="header-cart-item-txt">-->
                    <!--<a href="#" class="header-cart-item-name">-->
                      <!--Nixon Porter Leather Watch In Tan-->
                    <!--</a>-->

                    <!--<span class="header-cart-item-info">-->
                      <!--1 x $17.00-->
                    <!--</span>-->
                  <!--</div>-->
                <!--</li>-->
              <!--</ul>-->

              <!--<div class="header-cart-total">-->
                <!--Total: $75.00-->
              <!--</div>-->

              <!--<div class="header-cart-buttons">-->
                <!--<div class="header-cart-wrapbtn">-->
                  <!--&lt;!&ndash; Button &ndash;&gt;-->
                  <!--<a href="cart.html" class="flex-c-m size1 bg1 bo-rad-20 hov1 s-text1 trans-0-4">-->
                    <!--View Cart-->
                  <!--</a>-->
                <!--</div>-->

                <!--<div class="header-cart-wrapbtn">-->
                  <!--&lt;!&ndash; Button &ndash;&gt;-->
                  <!--<a href="#" class="flex-c-m size1 bg1 bo-rad-20 hov1 s-text1 trans-0-4">-->
                    <!--Check Out-->
                  <!--</a>-->
                <!--</div>-->
              <!--</div>-->
            <!--</div>-->
          </div>
        </div>
      </div>
    </div>

    <!-- Header Mobile -->
    <div class="wrap_header_mobile">
      <!-- Logo moblie -->
      <a href="home" class="logo-mobile">
        <img src="images/icons/logo.png" alt="IMG-LOGO">
      </a>

      <!-- Button show menu -->
      <div class="btn-show-menu">
        <!-- Header Icon mobile -->
        <div class="header-icons-mobile">
          <a href="#" class="header-wrapicon1 dis-block">
            <img src="images/icons/icon-header-01.png" class="header-icon1" alt="ICON">
          </a>

          <!--<span class="linedivide2"></span>-->

          <!--<div class="header-wrapicon2">-->
            <!--<img src="images/icons/icon-header-02.png" class="header-icon1 js-show-header-dropdown" alt="ICON">-->
            <!--<span class="header-icons-noti">0</span>-->

            <!--&lt;!&ndash; Header cart noti &ndash;&gt;-->
            <!--<div class="header-cart header-dropdown">-->
              <!--<ul class="header-cart-wrapitem">-->
                <!--<li class="header-cart-item">-->
                  <!--<div class="header-cart-item-img">-->
                    <!--<img src="images/item-cart-01.jpg" alt="IMG">-->
                  <!--</div>-->

                  <!--<div class="header-cart-item-txt">-->
                    <!--<a href="#" class="header-cart-item-name">-->
                      <!--White Shirt With Pleat Detail Back-->
                    <!--</a>-->

                    <!--<span class="header-cart-item-info">-->
                      <!--1 x $19.00-->
                    <!--</span>-->
                  <!--</div>-->
                <!--</li>-->

                <!--<li class="header-cart-item">-->
                  <!--<div class="header-cart-item-img">-->
                    <!--<img src="images/item-cart-02.jpg" alt="IMG">-->
                  <!--</div>-->

                  <!--<div class="header-cart-item-txt">-->
                    <!--<a href="#" class="header-cart-item-name">-->
                      <!--Converse All Star Hi Black Canvas-->
                    <!--</a>-->

                    <!--<span class="header-cart-item-info">-->
                      <!--1 x $39.00-->
                    <!--</span>-->
                  <!--</div>-->
                <!--</li>-->

                <!--<li class="header-cart-item">-->
                  <!--<div class="header-cart-item-img">-->
                    <!--<img src="images/item-cart-03.jpg" alt="IMG">-->
                  <!--</div>-->

                  <!--<div class="header-cart-item-txt">-->
                    <!--<a href="#" class="header-cart-item-name">-->
                      <!--Nixon Porter Leather Watch In Tan-->
                    <!--</a>-->

                    <!--<span class="header-cart-item-info">-->
                      <!--1 x $17.00-->
                    <!--</span>-->
                  <!--</div>-->
                <!--</li>-->
              <!--</ul>-->

              <!--<div class="header-cart-total">-->
                <!--Total: $75.00-->
              <!--</div>-->

              <!--<div class="header-cart-buttons">-->
                <!--<div class="header-cart-wrapbtn">-->
                  <!--&lt;!&ndash; Button &ndash;&gt;-->
                  <!--<a href="cart.html" class="flex-c-m size1 bg1 bo-rad-20 hov1 s-text1 trans-0-4">-->
                    <!--View Cart-->
                  <!--</a>-->
                <!--</div>-->

                <!--<div class="header-cart-wrapbtn">-->
                  <!--&lt;!&ndash; Button &ndash;&gt;-->
                  <!--<a href="#" class="flex-c-m size1 bg1 bo-rad-20 hov1 s-text1 trans-0-4">-->
                    <!--Check Out-->
                  <!--</a>-->
                <!--</div>-->
              <!--</div>-->
            <!--</div>-->
          </div>
        </div>

        <div class="btn-show-menu-mobile hamburger hamburger--squeeze">
          <span class="hamburger-box">
            <span class="hamburger-inner"></span>
          </span>
        </div>
      </div>
    </div>

    <!-- Menu Mobile -->
    <div class="wrap-side-menu" >
      <nav class="side-menu">
        <ul class="main-menu">
          <li class="item-topbar-mobile p-l-20 p-t-8 p-b-8">
            <span class="topbar-child1">
              Register to get notified for your required product.
            </span>
          </li>

          <!--<li class="item-topbar-mobile p-l-20 p-t-8 p-b-8">-->
            <!--<div class="topbar-child2-mobile">-->
              <!--<span class="topbar-email">-->
                <!--fashe@example.com-->
              <!--</span>-->

              <!--<div class="topbar-language rs1-select2">-->
                <!--<select class="selection-1" name="time">-->
                  <!--<option>USD</option>-->
                  <!--<option>EUR</option>-->
                <!--</select>-->
              <!--</div>-->
            <!--</div>-->
          <!--</li>-->

          <li class="item-topbar-mobile p-l-10">
            <div class="topbar-social-mobile">
              <a href="#" class="topbar-social-item fa fa-facebook"></a>
              <a href="#" class="topbar-social-item fa fa-instagram"></a>
              <a href="#" class="topbar-social-item fa fa-pinterest-p"></a>
              <a href="#" class="topbar-social-item fa fa-snapchat-ghost"></a>
              <a href="#" class="topbar-social-item fa fa-youtube-play"></a>
            </div>
          </li>

          <!--<li class="item-menu-mobile">-->
            <!--<a href="index.html">Home</a>-->
            <!--<ul class="sub-menu">-->
              <!--<li><a href="index.html">Homepage V1</a></li>-->
              <!--<li><a href="home-02.html">Homepage V2</a></li>-->
              <!--<li><a href="home-03.html">Homepage V3</a></li>-->
            <!--</ul>-->
            <!--<i class="arrow-main-menu fa fa-angle-right" aria-hidden="true"></i>-->
          <!--</li>-->

          <li class="item-menu-mobile">
            <a href="#">MEN</a>
          </li>

          <li class="item-menu-mobile">
            <a href="#">WOMEN</a>
          </li>

          <li class="item-menu-mobile">
            <a href="#">KIDS</a>
          </li>

          <li class="item-menu-mobile">
            <a href="#">BRANDS</a>
          </li>

          <li class="item-menu-mobile">
            <a href="#">ABOUT</a>
          </li>

          <li class="item-menu-mobile">
            <a href="#">CONTACT</a>
          </li>
        </ul>
      </nav>
    </div>
  </header>

  <!-- Slide1 -->
 @if($slider=='on')
 
  <section class="slide1">
    <div class="wrap-slick1">
      <div class="slick1">
        <div class="item-slick1 item1-slick1" style="background-image: url(images/master-slide-01.jpg);">
          <div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
            <span class="caption1-slide1 m-text1 t-center animated visible-false m-b-15" data-appear="fadeInDown">
              Women Collection 2018
            </span>

            <h2 class="caption2-slide1 xl-text1 t-center animated visible-false m-b-37" data-appear="fadeInUp">
              New arrivals
            </h2>

            <div class="wrap-btn-slide1 w-size1 animated visible-false" data-appear="zoomIn">
              <!-- Button -->
              <a href="product.html" class="flex-c-m size2 bo-rad-23 s-text2 bgwhite hov1 trans-0-4">
                Shop Now
              </a>
            </div>
          </div>
        </div>

        <div class="item-slick1 item2-slick1" style="background-image: url(images/master-slide-02.jpg);">
          <div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
            <span class="caption1-slide1 m-text1 t-center animated visible-false m-b-15" data-appear="rollIn">
              Women Collection 2018
            </span>

            <h2 class="caption2-slide1 xl-text1 t-center animated visible-false m-b-37" data-appear="lightSpeedIn">
              New arrivals
            </h2>

            <div class="wrap-btn-slide1 w-size1 animated visible-false" data-appear="slideInUp">
              <!-- Button -->
              <a href="product.html" class="flex-c-m size2 bo-rad-23 s-text2 bgwhite hov1 trans-0-4">
                Shop Now
              </a>
            </div>
          </div>
        </div>

        <div class="item-slick1 item2-slick1" style="background-image: url(images/master-slide-03.jpg);">
          <div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
            <span class="caption1-slide1 m-text1 t-center animated visible-false m-b-15" data-appear="rollIn">
              Women Collection 2018
            </span>

            <h2 class="caption2-slide1 xl-text1 t-center animated visible-false m-b-37" data-appear="lightSpeedIn">
              New arrivals
            </h2>

            <div class="wrap-btn-slide1 w-size1 animated visible-false" data-appear="slideInUp">
              <!-- Button -->
              <a href="product.html" class="flex-c-m size2 bo-rad-23 s-text2 bgwhite hov1 trans-0-4">
                Shop Now
              </a>
            </div>
          </div>
        </div>

        <div class="item-slick1 item3-slick1" style="background-image: url(images/master-slide-04.jpg);">
          <div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
            <span class="caption1-slide1 m-text1 t-center animated visible-false m-b-15" data-appear="rotateInDownLeft">
              Women Collection 2018
            </span>

            <h2 class="caption2-slide1 xl-text1 t-center animated visible-false m-b-37" data-appear="rotateInUpRight">
              New arrivals
            </h2>

            <div class="wrap-btn-slide1 w-size1 animated visible-false" data-appear="rotateIn">
              <!-- Button -->
              <a href="product.html" class="flex-c-m size2 bo-rad-23 s-text2 bgwhite hov1 trans-0-4">
                Shop Now
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

@endif



    @yield('home')
    @yield('pak')
    @yield('product')
    @yield('brands') 
    @yield('ebay')
    @yield('search')









   <section class="instagram p-t-20">
    <div class="sec-title p-b-52 p-l-15 p-r-15">
      <h3 class="m-text5 t-center">
        @ follow us on Instagram
      </h3>
    </div>

    <div class="flex-w">
      <!-- Block4 -->
      <div class="block4 wrap-pic-w">
        <img src="images/gallery-03.jpg" alt="IMG-INSTAGRAM">

        <a href="#" class="block4-overlay sizefull ab-t-l trans-0-4">
          <span class="block4-overlay-heart s-text9 flex-m trans-0-4 p-l-40 p-t-25">
            <i class="icon_heart_alt fs-20 p-r-12" aria-hidden="true"></i>
            <span class="p-t-2">39</span>
          </span>

          <div class="block4-overlay-txt trans-0-4 p-l-40 p-r-25 p-b-30">
            <p class="s-text10 m-b-15 h-size1 of-hidden">
              Nullam scelerisque, lacus sed consequat laoreet, dui enim iaculis leo, eu viverra ex nulla in tellus. Nullam nec ornare tellus, ac fringilla lacus. Ut sit amet enim orci. Nam eget metus elit.
            </p>

            <span class="s-text9">
              Photo by @nancyward
            </span>
          </div>
        </a>
      </div>

      <!-- Block4 -->
      <div class="block4 wrap-pic-w">
        <img src="images/gallery-07.jpg" alt="IMG-INSTAGRAM">

        <a href="#" class="block4-overlay sizefull ab-t-l trans-0-4">
          <span class="block4-overlay-heart s-text9 flex-m trans-0-4 p-l-40 p-t-25">
            <i class="icon_heart_alt fs-20 p-r-12" aria-hidden="true"></i>
            <span class="p-t-2">39</span>
          </span>

          <div class="block4-overlay-txt trans-0-4 p-l-40 p-r-25 p-b-30">
            <p class="s-text10 m-b-15 h-size1 of-hidden">
              Nullam scelerisque, lacus sed consequat laoreet, dui enim iaculis leo, eu viverra ex nulla in tellus. Nullam nec ornare tellus, ac fringilla lacus. Ut sit amet enim orci. Nam eget metus elit.
            </p>

            <span class="s-text9">
              Photo by @nancyward
            </span>
          </div>
        </a>
      </div>

      <!-- Block4 -->
      <div class="block4 wrap-pic-w">
        <img src="images/gallery-09.jpg" alt="IMG-INSTAGRAM">

        <a href="#" class="block4-overlay sizefull ab-t-l trans-0-4">
          <span class="block4-overlay-heart s-text9 flex-m trans-0-4 p-l-40 p-t-25">
            <i class="icon_heart_alt fs-20 p-r-12" aria-hidden="true"></i>
            <span class="p-t-2">39</span>
          </span>

          <div class="block4-overlay-txt trans-0-4 p-l-40 p-r-25 p-b-30">
            <p class="s-text10 m-b-15 h-size1 of-hidden">
              Nullam scelerisque, lacus sed consequat laoreet, dui enim iaculis leo, eu viverra ex nulla in tellus. Nullam nec ornare tellus, ac fringilla lacus. Ut sit amet enim orci. Nam eget metus elit.
            </p>

            <span class="s-text9">
              Photo by @nancyward
            </span>
          </div>
        </a>
      </div>

      <!-- Block4 -->
      <div class="block4 wrap-pic-w">
        <img src="images/gallery-13.jpg" alt="IMG-INSTAGRAM">

        <a href="#" class="block4-overlay sizefull ab-t-l trans-0-4">
          <span class="block4-overlay-heart s-text9 flex-m trans-0-4 p-l-40 p-t-25">
            <i class="icon_heart_alt fs-20 p-r-12" aria-hidden="true"></i>
            <span class="p-t-2">39</span>
          </span>

          <div class="block4-overlay-txt trans-0-4 p-l-40 p-r-25 p-b-30">
            <p class="s-text10 m-b-15 h-size1 of-hidden">
              Nullam scelerisque, lacus sed consequat laoreet, dui enim iaculis leo, eu viverra ex nulla in tellus. Nullam nec ornare tellus, ac fringilla lacus. Ut sit amet enim orci. Nam eget metus elit.
            </p>

            <span class="s-text9">
              Photo by @nancyward
            </span>
          </div>
        </a>
      </div>

      <!-- Block4 -->
      <div class="block4 wrap-pic-w">
        <img src="images/gallery-15.jpg" alt="IMG-INSTAGRAM">

        <a href="#" class="block4-overlay sizefull ab-t-l trans-0-4">
          <span class="block4-overlay-heart s-text9 flex-m trans-0-4 p-l-40 p-t-25">
            <i class="icon_heart_alt fs-20 p-r-12" aria-hidden="true"></i>
            <span class="p-t-2">39</span>
          </span>

          <div class="block4-overlay-txt trans-0-4 p-l-40 p-r-25 p-b-30">
            <p class="s-text10 m-b-15 h-size1 of-hidden">
              Nullam scelerisque, lacus sed consequat laoreet, dui enim iaculis leo, eu viverra ex nulla in tellus. Nullam nec ornare tellus, ac fringilla lacus. Ut sit amet enim orci. Nam eget metus elit.
            </p>

            <span class="s-text9">
              Photo by @nancyward
            </span>
          </div>
        </a>
      </div>
    </div>
  </section>

  <!--&lt;!&ndash; Shipping &ndash;&gt;-->
  <!--<section class="shipping bgwhite p-t-62 p-b-46">-->
    <!--<div class="flex-w p-l-15 p-r-15">-->
      <!--<div class="flex-col-c w-size5 p-l-15 p-r-15 p-t-16 p-b-15 respon1">-->
        <!--<h4 class="m-text12 t-center">-->
          <!--Free Delivery Worldwide-->
        <!--</h4>-->

        <!--<a href="#" class="s-text11 t-center">-->
          <!--Click here for more info-->
        <!--</a>-->
      <!--</div>-->

      <!--<div class="flex-col-c w-size5 p-l-15 p-r-15 p-t-16 p-b-15 bo2 respon2">-->
        <!--<h4 class="m-text12 t-center">-->
          <!--30 Days Return-->
        <!--</h4>-->

        <!--<span class="s-text11 t-center">-->
          <!--Simply return it within 30 days for an exchange.-->
        <!--</span>-->
      <!--</div>-->

      <!--<div class="flex-col-c w-size5 p-l-15 p-r-15 p-t-16 p-b-15 respon1">-->
        <!--<h4 class="m-text12 t-center">-->
          <!--Store Opening-->
        <!--</h4>-->

        <!--<span class="s-text11 t-center">-->
          <!--Shop open from Monday to Sunday-->
        <!--</span>-->
      <!--</div>-->
    <!--</div>-->
  <!--</section>-->


  <!-- Footer -->
  <footer class="bg6 p-t-45 p-b-43 p-l-45 p-r-45">
    <div class="flex-w p-b-90">
      <div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
        <h4 class="s-text12 p-b-30">
          GET IN TOUCH
        </h4>

        <div>
          <p class="s-text7 w-size27">
            Any questions? Let us know on our email support@cartcrawler.com or contact us at 03342223163
          </p>

          <div class="flex-m p-t-30">
            <a href="#" class="fs-18 color1 p-r-20 fa fa-facebook"></a>
            <a href="#" class="fs-18 color1 p-r-20 fa fa-instagram"></a>
            <a href="#" class="fs-18 color1 p-r-20 fa fa-pinterest-p"></a>
            <a href="#" class="fs-18 color1 p-r-20 fa fa-snapchat-ghost"></a>
            <a href="#" class="fs-18 color1 p-r-20 fa fa-youtube-play"></a>
          </div>
        </div>
      </div>

      <div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
        <h4 class="s-text12 p-b-30">
          Categories
        </h4>

        <ul>
          <li class="p-b-9">
            <a href="#" class="s-text7">
              Men
            </a>
          </li>

          <li class="p-b-9">
            <a href="#" class="s-text7">
              Women
            </a>
          </li>

          <li class="p-b-9">
            <a href="#" class="s-text7">
              Kids
            </a>
          </li>

          <li class="p-b-9">
            <a href="#" class="s-text7">
              Brands
            </a>
          </li>
        </ul>
      </div>

      <div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
        <h4 class="s-text12 p-b-30">
          Links
        </h4>

        <ul>
          <li class="p-b-9">
            <a href="#" class="s-text7">
              Search
            </a>
          </li>

          <li class="p-b-9">
            <a href="#" class="s-text7">
              About Us
            </a>
          </li>

          <li class="p-b-9">
            <a href="#" class="s-text7">
              Contact Us
            </a>
          </li>


        </ul>
      </div>

      <div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
        <h4 class="s-text12 p-b-30">
          Help
        </h4>

        <ul>

          <li class="p-b-9">
            <a href="#" class="s-text7">
              FAQs
            </a>
          </li>
        </ul>
      </div>

      <div class="w-size8 p-t-30 p-l-15 p-r-15 respon3">
        <h4 class="s-text12 p-b-30">
          Newsletter
        </h4>

        <form>
          <div class="effect1 w-size9">
            <input class="s-text7 bg6 w-full p-b-5" type="text" name="email" placeholder="email@example.com">
            <span class="effect1-line"></span>
          </div>

          <div class="w-size2 p-t-20">
            <!-- Button -->
            <button class="flex-c-m size2 bg4 bo-rad-23 hov1 m-text3 trans-0-4">
              Subscribe
            </button>
          </div>

        </form>
      </div>
    </div>

    <div class="t-center p-l-15 p-r-15">
      <div class="t-center s-text8 p-t-20">
        Copyright © 2018 All rights reserved.
      </div>
    </div>
  </footer>



  <!-- Back to top -->
  <div class="btn-back-to-top bg0-hov" id="myBtn">
    <span class="symbol-btn-back-to-top">
      <i class="fa fa-angle-double-up" aria-hidden="true"></i>
    </span>
  </div>

  <!-- Container Selection1 -->
  <div id="dropDownSelect1"></div>



<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
  <script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/select2/select2.min.js"></script>
  <script type="text/javascript">
    $(".selection-1").select2({
      minimumResultsForSearch: 20,
      dropdownParent: $('#dropDownSelect1')
    });
  </script>
<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/slick/slick.min.js"></script>
  <script type="text/javascript" src="js/slick-custom.js"></script>
<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
  <script type="text/javascript" src="vendor/sweetalert/sweetalert.min.js"></script>
  <!--<script type="text/javascript">-->
    <!--$('.block2-btn-addcart').each(function(){-->
      <!--var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();-->
      <!--$(this).on('click', function(){-->
        <!--swal(nameProduct, "is added to cart !", "success");-->
      <!--});-->
    <!--});-->

    <!--$('.block2-btn-addwishlist').each(function(){-->
      <!--var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();-->
      <!--$(this).on('click', function(){-->
        <!--swal(nameProduct, "is added to wishlist !", "success");-->
      <!--});-->
    <!--});-->
  <!--</script>-->

<!--===============================================================================================-->
  <script src="js/main.js"></script>

<div class="modal fade" id="alert" tabindex="-1" role="dialog"  style="    left: 191px;">
  <div class="modal-dialog" style="top: 25%;">
    <!-- Modal content-->
    
  
      <div class="modal-body modal-body-sub_agile" >
        <div class="col-md-8 modal_body_left modal_body_left1 model-class">
       
          <form  method="post" action="setalert">
            
         
            <div class="styled-input">
            <input type="hidden" id="nameofalert"  name="alertname" >
            <input type="hidden" id="nameofweb" name="webtname" >
            <input type="hidden" id="username" value="ali" >
              <select class="nodeinput" style="width: 100%;padding:5" id="offvalue" name="offalert" required>
                <option>Required %age</option>
              <?php for($i=1;$i<=100;$i++)
              {?>
              
<option value="<?php echo $i; ?>"> <?php echo $i.' %'; ?> </option>

              <?php }?></select>
              <span></span></div>
            
            <input type="button"   onclick="save_result()" class="custom-btn" value="Set Alert" style="margin-top:10px;">
          </form>
         
        <div class="clearfix"></div>
      </div>
    </div>
    <!-- //Modal content-->
  </div>
</div>




<!--  search model -->


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 99999;">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Please Type Search</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="padding: 0px">
          <span aria-hidden="true" style="font-size: 34px">×</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="search">
          {{Csrf_field()}}
          <div class="form-group">
            
            <input type="text" class="nodeinput" autofocus="autofocus" name="searchinput" placeholder="i want to search....." id="recipient-name">
          </div>
          <div class="form-group">
            <select name="selectinput" class="nodeinput" style="width:100%">
  <option value="">choose website</option>
 
  <option value="puma.us">Puma</option>
<option value="ebay.com">Ebay</option>
  <option value="pakstyle">Pakstyle</option>
   <option value="all">All</option>




</select>

          </div>
        
      </div>
      <div class="modal-footer">
        
        <button type="submit"  onclick="hide_search()" class="custom-btn"><i class="fa fa-search"></i> search</button></form>
      </div>
    </div>
  </div>
</div>




</body>
</html>



<script type="text/javascript">
  function hide_search()
  {

$("#exampleModal").hide();

  }
function blur_body()
{

  document.getElementById("#body-fade").style.opacity=".6";
  return false;
}

    

    function set_alert(name,web)
    {
$("#nameofalert").val(name);
$("#nameofweb").val(web);

    }
function save_result()
{

var name=document.getElementById("nameofalert").value;

var web=document.getElementById("nameofweb").value;

var off=document.getElementById("offvalue").value;

var user=document.getElementById("username").value;

$.post('lib/setalert',{namevalue:name,webvalue:web,offvalue:off,uservalue:user},function(data)



{

  alert(data);
}

  );

}
     
  </script>