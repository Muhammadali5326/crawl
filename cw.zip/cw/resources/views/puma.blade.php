<h1 style="color: tomato;text-align: center;margin:12px;">Footwear</h1>

<?php

	 $html->load(curl('https://us.puma.com/on/demandware.store/Sites-NA-Site/en_US/Search-UpdateGrid?cgid=21100&sz=120&start=143'));

foreach($html->find('div[class=grid-tile col-6 col-sm-4 col-md-3]') as $key)
{
	


		
$item['name']= $key->find('div[class=pdp-link] a ',0)->innertext;
	$name=html_entity_decode(trim($item['name']));
		//echo $name."<br>";


	$price['price']= $key->find('span[class=sales] span[class=value] ',0)->plaintext;
	$prices=html_entity_decode(trim($price['price']));
	//echo $prices."<br>";

	$off['off']= $key->find('span[class=strike-through list] span ',0)->plaintext;
	$offprice=html_entity_decode(trim($off['off']));
	//echo $offprice."<br>";


		$realprice=str_replace("$","",$prices);
 		"<b>";
 		$realoff=str_replace("$","",$offprice);	
 		"<b>";
	
 $sale=100-(($realprice/$realoff)*100);
 $sale=ceil($sale);


$imgurl['imgurl']= $key->find('div[class=image-container] a img',0)->getAttribute('src');
$image=html_entity_decode(trim($imgurl['imgurl']));
	

?>

<div class="col-md-3" style="overflow: hidden;">
							<div class="product-shoe-info shoe">
								<div class="men-pro-item">
									<a href="#" data-toggle="modal"   data-target="#alert"><span  style="border:1px solid white; color:#ccc; font-family: sans-serif; font-size: 18px"><i class="fa fa-heart-o"></i></a>


									</span>
									<div class="men-thumb-item" style="position: static;">
										<img src="<?php echo $image ?>" class=" img-responsive" style="height:175px; width:300px" />
										<?php if($offprice){?>
		<span class="product-new-top" style="background:red; border:1px solid white; color:white; font-family: sans-serif;"><?php echo $sale." %off";  ?></span> <?php } 
		?>

									</div>

									<div class="item-info-product">
										<h4>
<a href="#"><?php echo "
<p style='          text-align: left;
    overflow: hidden;
    margin-top: 13px;
    padding: 0px;
    font-size: 12px;
    width: 194px;
    height: 24px;
    font-weight: initial;
    font-family: sans-serif;'>".$name."</p>"; ?> </a>
										</h4>
										<div class="info-product-price">
											<div class="grid_meta">
												<div class="product_price">
													<div class="col-sm-6 ">
		<span class="money" style="color: green">
			<?php echo $prices; ?>
			</span></div>
		
<div class="col-sm-6 ">

			<?php echo '<del style="color:red">'.$offprice.'</del>'; ?>
			
		</div></div>

													</div>


												</div>
												
											</div>
											
										</div>
										<div class="clearfix"></div>
									</div>
								</div>
      <?php







	}

//cho count($count);
	?>
