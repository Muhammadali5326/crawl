
@extends('layout/header')
@section('pak')
<section class="bgwhite p-t-55 p-b-65">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-md-4 col-lg-3 p-b-50">
					<div class="leftbar p-r-20 p-r-0-sm">
						<!--  -->
						<h4 class="m-text14 p-b-7">
							Categories
						</h4>

						<ul class="p-b-54">
							<li class="p-t-4">
								<a href="#" class="s-text13 active1">
									All
								</a>
							</li>

							<li class="p-t-4">
								<a href="#" class="s-text13">
									Women
								</a>
							</li>

							<li class="p-t-4">
								<a href="#" class="s-text13">
									Men
								</a>
							</li>

							<li class="p-t-4">
								<a href="#" class="s-text13">
									Kids
								</a>
							</li>


						</ul>

						<!--  -->
						<h4 class="m-text14 p-b-32">
							Filters
						</h4>

						<div class="filter-price p-t-22 p-b-50 bo3">
							<div class="m-text15 p-b-17">
								Price
							</div>

							<div class="wra-filter-bar">
								<div id="filter-bar"></div>
							</div>

							<div class="flex-sb-m flex-w p-t-16">
								<div class="s-text3 p-t-10 p-b-10">
									Range: $<span id="value-lower">610</span> - $<span id="value-upper">980</span>
								</div>
							</div>
						</div>

						<div class="filter-color p-t-22 p-b-50 bo3">
							<div class="m-text15 p-b-12">
								Color
							</div>

							<ul class="flex-w">
								<li class="m-r-10">
									<input class="checkbox-color-filter" id="color-filter1" type="checkbox" name="color-filter1">
									<label class="color-filter color-filter1" for="color-filter1"></label>
								</li>

								<li class="m-r-10">
									<input class="checkbox-color-filter" id="color-filter2" type="checkbox" name="color-filter2">
									<label class="color-filter color-filter2" for="color-filter2"></label>
								</li>

								<li class="m-r-10">
									<input class="checkbox-color-filter" id="color-filter3" type="checkbox" name="color-filter3">
									<label class="color-filter color-filter3" for="color-filter3"></label>
								</li>

								<li class="m-r-10">
									<input class="checkbox-color-filter" id="color-filter4" type="checkbox" name="color-filter4">
									<label class="color-filter color-filter4" for="color-filter4"></label>
								</li>

								<li class="m-r-10">
									<input class="checkbox-color-filter" id="color-filter5" type="checkbox" name="color-filter5">
									<label class="color-filter color-filter5" for="color-filter5"></label>
								</li>

								<li class="m-r-10">
									<input class="checkbox-color-filter" id="color-filter6" type="checkbox" name="color-filter6">
									<label class="color-filter color-filter6" for="color-filter6"></label>
								</li>

								<li class="m-r-10">
									<input class="checkbox-color-filter" id="color-filter7" type="checkbox" name="color-filter7">
									<label class="color-filter color-filter7" for="color-filter7"></label>
								</li>
							</ul>
						</div>

						<div class="w-size11">
							<!-- Button -->
							<button class="flex-c-m size9 bg7 bo-rad-15 hov1 s-text14 trans-0-4">
								Apply Filters
							</button>
						</div>

					</div>
				</div>

				<div class="col-sm-6 col-md-8 col-lg-9 p-b-50">
					<!--  -->
					<div class="flex-sb-m flex-w p-b-35">
						<div class="flex-w">
							<div class="rs2-select2 bo4 of-hidden w-size12 m-t-5 m-b-5 m-r-10">
								<select class="selection-2" name="sorting">
									<option>Default Sorting</option>
									<option>Popularity</option>
									<option>Price: low to high</option>
									<option>Price: high to low</option>
								</select>
							</div>

							<div class="rs2-select2 bo4 of-hidden w-size12 m-t-5 m-b-5 m-r-10">
								<select class="selection-2" name="sorting">
									<option>Price</option>
									<option>$0.00 - $50.00</option>
									<option>$50.00 - $100.00</option>
									<option>$100.00 - $150.00</option>
									<option>$150.00 - $200.00</option>
									<option>$200.00+</option>

								</select>
							</div>
						</div>

						<span class="s-text8 p-t-5 p-b-5">
							Showing 1–12 of 16 results
						</span>
					</div>

					<!-- Product -->
					<div class="row">

<?php 
$html=new simple_html_dom();
		$html->load(curl('https://www.pakstyle.pk/search/shoes'));

foreach($html->find('div[class=single-product]') as $key)
{
		$out['out']= $key->find('div[class=pro-content text_ac] span  b ',0)->plaintext;
	$stock=html_entity_decode(trim($out['out']));
	//echo $name."<br>";
	 if($stock!='Out of Stock')
	 { 
		
$item['name']= $key->find('div[class=pro-content text_ac] p  b ',0)->innertext;
	$name=html_entity_decode(trim($item['name']));
	//echo $name."<br>";
	
	

	
	
	$price['amount']= $key->find('div[class=pro-content text_ac] p  span ',0)->plaintext;
	$saleprice=html_entity_decode(trim($price['amount']));
	
	
	$real_amount=str_replace("Rs.","",$saleprice);
	//echo $amount."<br>";
	
$del['del']= $key->find('div[class=pro-content text_ac] p  del ',0)->plaintext;
	$originalprice=html_entity_decode(trim($del['del']));
	$real_disc=str_replace("Rs.","",$originalprice);
	//echo $disc."<br>";
	
 $sale=100-(($real_amount/$real_disc)*100);

	$img['image']= $key->find('div[class=pro-img] img',0)->getAttribute('src');
	$image=html_entity_decode(trim($img['image']));
	
	//echo $image."</br>";
	?>
<div class="col-sm-12 col-md-6 col-lg-4 p-b-50 div-border">
							<!-- Block2 --><?php if($originalprice){ ?>
										<span class="offsale"><?php echo ceil($sale) ." %"; ?></span> <?php }?>
							<div class="block2">

								<div class="block2-img wrap-pic-w of-hidden pos-relative ">
									
									<img src="<?php echo $image ?>" alt="IMG-PRODUCT">

									<div class="block2-overlay trans-0-4">
										<a href="#" data-toggle="modal"  data-target="#alert" class="block2-btn-addwishlist hov-pointer trans-0-4">
											<i class="icon-wishlist icon_heart_alt" aria-hidden="true"></i>
											<i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
										</a>

										
									</div>
								</div>

								<div class="block2-txt p-t-20">
									<a href="product-detail.html" class="block2-name dis-block s-text3 p-b-5">
										<?php echo $name ?>
									</a>

									<span class="block2-price m-text6 p-r-5">
										<?php echo $saleprice; ?>
									</span>
									<?php if($originalprice){ ?>
									<span class="block2-price m-text6 p-r-5" style="float: right;">
										<del style="color: red"><?php echo $originalprice; ?></del>
									</span><?php }?>
								</div>
							</div>
						</div>
						
<?php
	

	 }
	else
	{
	
	
	
		
		}
}
	
	?>

	</div>


					<!-- Pagination -->
					<div class="pagination flex-m flex-w p-t-26">
						<a href="#" class="item-pagination flex-c-m trans-0-4 active-pagination">1</a>
						<a href="#" class="item-pagination flex-c-m trans-0-4">2</a>
					</div>
				</div>
			</div>
		</div>
	</section>
@endsection

