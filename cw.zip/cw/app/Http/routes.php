<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
Route::get('pak','Crawl@pak');

Route::get('home','Crawl@home');

Route::get('footwear','Crawl@footwear');

Route::get('pakstyle','Crawl@wearable');

Route::get('nike','Crawl@nike');

Route::get('ebay','Crawl@ebay');

Route::get('brands','Crawl@brands');

Route::post('search','Crawl@search');

Route::post('/setalert','Crawl@setalert');
Route::get('/', function () {
    return view('welcome');
});
