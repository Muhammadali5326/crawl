<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Input;
use App\Requests;
class Crawl extends Controller
{



public function home()
	{
$url=URL::current();

if (strpos($url, 'home') !== false) {
   return view('home')->with('slider','on');

}
else
{
	return view('home');
}


	}


public function footwear()
	{

return view('product');

	}


	public function wearable()
	{

return view('pakstyle');

	}


		public function nike()
	{

return view('nike');

	}


	public function ebay()
	{

return view('ebay');

	}
    


    public function brands()
	{

return view('brands');

	}



	 public function search()
	{

$item_to_be_searched=input::get('searchinput');
$website_to_be_searched=input::get('selectinput');

return view('seacrh')->with('search',$item_to_be_searched)->with('website',$website_to_be_searched);

	}
}
