<?php $__env->startSection('brands'); ?><h3 class="m-text5 t-center" style="margin-top: 20px;">
        @ Best brands we have 
      </h3>
<section class="banner bgwhite p-t-40 p-b-40">
		<div class="container">
			<div class="row">
			

				<div class="col-sm-10 col-md-8 col-lg-4 m-l-r-auto">
					<!-- block1 -->
					<div class="block1 hov-img-zoom pos-relative m-b-30">
						<img src="https://wallpapercave.com/wp/57e4hub.jpg" alt="IMG-BENNER">

						<div class="block1-wrapbtn w-size2" style="    border-radius: 34px;">
							<!-- Button -->
							<a href="footwear" class="flex-c-m size2 m-text2 bg3 bo-rad-23 hov1 trans-0-4">
								Puma
							</a>
						</div>
					</div>

					<!-- block1 -->
					<!--<div class="block1 hov-img-zoom pos-relative m-b-30">-->
						<!--<img src="images/banner-07.jpg" alt="IMG-BENNER">-->

						<!--<div class="block1-wrapbtn w-size2">-->
							<!--&lt;!&ndash; Button &ndash;&gt;-->
							<!--<a href="#" class="flex-c-m size2 m-text2 bg3 hov1 trans-0-4">-->
								<!--Footerwear-->
							<!--</a>-->
						<!--</div>-->
					<!--</div>-->
				</div>

				<div class="col-sm-10 col-md-8 col-lg-4 m-l-r-auto">
					<!-- block1 -->
					<div class="block1 hov-img-zoom pos-relative m-b-30">
						<img src="https://images.pexels.com/photos/1124466/pexels-photo-1124466.jpeg?auto=compress&cs=tinysrgb&h=950&w=940" alt="IMG-BENNER" style="height: 229px;">

						<div class="block1-wrapbtn w-size2" style="    border-radius: 34px;">
							<!-- Button -->
							<a href="ebay" class="flex-c-m size2 m-text2 bg3 bo-rad-23 hov1 trans-0-4">
								Nike
							</a>
						</div>
					</div>

					<!-- block1 -->
					<!--<div class="block1 hov-img-zoom pos-relative m-b-30">-->
						<!--<img src="images/banner-07.jpg" alt="IMG-BENNER">-->

						<!--<div class="block1-wrapbtn w-size2">-->
							<!--&lt;!&ndash; Button &ndash;&gt;-->
							<!--<a href="#" class="flex-c-m size2 m-text2 bg3 hov1 trans-0-4">-->
								<!--Footerwear-->
							<!--</a>-->
						<!--</div>-->
					<!--</div>-->
				</div>

				<div class="col-sm-10 col-md-8 col-lg-4 m-l-r-auto">
					<!-- block1 -->
					<div class="block1 hov-img-zoom pos-relative m-b-30">
						<img src="https://images.pexels.com/photos/57421/running-shoe-shoe-asics-highly-functional-57421.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="IMG-BENNER" style="height: 229px">

						<div class="block1-wrapbtn w-size2" style="    border-radius: 34px;">
							<!-- Button -->
							<a href="pakstyle" class="flex-c-m size2 m-text2 bg3 bo-rad-23 hov1 trans-0-4">
								Pakstyle
							</a>
						</div>
					</div>

					<!-- block1 -->
					<!--<div class="block1 hov-img-zoom pos-relative m-b-30">-->
						<!--<img src="images/banner-07.jpg" alt="IMG-BENNER">-->

						<!--<div class="block1-wrapbtn w-size2">-->
							<!--&lt;!&ndash; Button &ndash;&gt;-->
							<!--<a href="#" class="flex-c-m size2 m-text2 bg3 hov1 trans-0-4">-->
								<!--Footerwear-->
							<!--</a>-->
						<!--</div>-->
					<!--</div>-->
				</div>

				
			</div>
		</div>
	</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>